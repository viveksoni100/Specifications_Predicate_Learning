package tk.learntosuccess;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

public class App {

	public static void main(String[] args) {
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("CreteriaApiInJpa");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Employee> createQuery = criteriaBuilder.createQuery(Employee.class);
		Root<Employee> from = createQuery.from(Employee.class);
		createQuery.select(from);
		
		TypedQuery<Employee> typedQuery = entityManager.createQuery(createQuery);
		List<Employee> emplist = typedQuery.getResultList();
		for (Employee employee : emplist) {
			System.out.println(employee);
		}
		
		
		
		entityManager.close();
		entityManagerFactory.close();
	}

}
