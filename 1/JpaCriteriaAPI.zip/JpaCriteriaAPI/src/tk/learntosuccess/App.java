package tk.learntosuccess;

import java.math.BigDecimal;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.eclipse.persistence.internal.jpa.querydef.SelectionImpl;

public class App {

	public static void main(String[] args) {
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("JpaCriteriaAPI");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
//getting all employee records
		// CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		// CriteriaQuery<Employee> createQuery =
		// criteriaBuilder.createQuery(Employee.class);
		// Root<Employee> root = createQuery.from(Employee.class);
		// createQuery.select(root);
		//
		// TypedQuery<Employee> createQuery2 = entityManager.createQuery(createQuery);
		// List<Employee> emplist = createQuery2.getResultList();
		// for (Employee employee : emplist) {
		// System.out.println(employee);
		// }

		
		//getting few columns from table 
		// CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		// CriteriaQuery<BigDecimal> createQuery =
		// criteriaBuilder.createQuery(BigDecimal.class);
		// Root<Employee> root = createQuery.from(Employee.class);
		// createQuery.select(root.get("salary"));
		//
		// TypedQuery<BigDecimal> createQuery2 = entityManager.createQuery(createQuery);
		// List<BigDecimal> resultList = createQuery2.getResultList();
		// for (BigDecimal employee : resultList) {
		// System.out.println(employee);
		// }

		
		//based on the condition sorting the records
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Employee> createQuery = criteriaBuilder.createQuery(Employee.class);
		Root<Employee> root = createQuery.from(Employee.class);

		createQuery.where(criteriaBuilder.greaterThan(root.get("salary"), 40000));

		TypedQuery<Employee> createQuery2 = entityManager.createQuery(createQuery);
		List<Employee> resultList = createQuery2.getResultList();
		for (Employee employee : resultList) {
			System.out.println(employee);
		}

		entityManager.close();
		entityManagerFactory.close();
	}

}
